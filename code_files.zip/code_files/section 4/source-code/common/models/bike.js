module.exports = function(Bike) {

};
