// Database URL
module.exports = {
    // Uncomment to connect with MongoDB on Cloud
    //'url' : 'mongodb://mvc-user-connect:opklnm@ds019028.mlab.com:19028/mvc-app'
    'url' : 'mongodb://localhost/mvc-app'
};
